<?php

require_once dirname(__FILE__) . '/Base.php';

class W3_Cdn_S3 extends W3_Cdn_Base 
{
}
